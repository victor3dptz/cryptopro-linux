#!/bin/bash

echo searching for Info.plist to update...
for file in $(find /usr/lib* -name "Info.plist" | grep "ifd-ccid.bundle/Contents" ); do
	echo updating $file

	#JaCarta
	bash ./ards_p11_update_ifd_ccid_bundle.sh $file "0x24DC" "0x0101" "ARDS JaCarta" > $file.tmp1
	bash ./ards_p11_update_ifd_ccid_bundle.sh $file.tmp1 "0x24DC" "0x100F" "ARDS ZAO JaCarta Flash" > $file.tmp
	
	chown --reference=$file $file.tmp
	chmod --reference=$file $file.tmp
	
	mv -f $file.tmp $file
	rm -f $file.tmp1
done

echo Done.
